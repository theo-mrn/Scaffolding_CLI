class GitHubError(Exception):
    pass
